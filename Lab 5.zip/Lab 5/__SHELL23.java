
public class __SHELL23 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
Game.main(__bluej_param0);

}}
